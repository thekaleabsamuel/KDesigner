#!/usr/bin/env python
# coding: utf8

""" Packages that provides static resources file for the library. """

__email__ = "spleeter@deezer.com"
__author__ = "Deezer Research"
__license__ = "MIT License"
