#!/usr/bin/env python
# coding: utf8

""" This package provides utility function and classes. """

__email__ = "spleeter@deezer.com"
__author__ = "Deezer Research"
__license__ = "MIT License"
